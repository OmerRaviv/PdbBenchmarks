﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Zodiacon.DebugHelp {
	public sealed class ModuleInfo {
		public string Name { get; set; }
		public ulong Base { get; set; }
	}
}
